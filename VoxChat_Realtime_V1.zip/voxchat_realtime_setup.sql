-- VoxChat V1: database + realtime messaging
-- Paste this whole script into Supabase > SQL Editor and run it.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.conversations (
  id uuid primary key default gen_random_uuid(),
  created_by uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.conversation_members (
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (conversation_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null check (char_length(trim(body)) between 1 and 4000),
  created_at timestamptz not null default now()
);

create index if not exists conversation_members_user_idx
  on public.conversation_members(user_id);

create index if not exists messages_conversation_created_idx
  on public.messages(conversation_id, created_at);

-- Automatically create a profile whenever a new Auth user is created.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, display_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'display_name', split_part(coalesce(new.email,''),'@',1))
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Security helper: avoids repeating membership logic in policies.
create or replace function public.is_conversation_member(p_conversation_id uuid)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = p_conversation_id
      and cm.user_id = auth.uid()
  );
$$;

grant execute on function public.is_conversation_member(uuid) to authenticated;

alter table public.profiles enable row level security;
alter table public.conversations enable row level security;
alter table public.conversation_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated"
on public.profiles for select
to authenticated
using (true);

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own"
on public.profiles for update
to authenticated
using (id = auth.uid())
with check (id = auth.uid());

drop policy if exists "conversations_select_members" on public.conversations;
create policy "conversations_select_members"
on public.conversations for select
to authenticated
using (public.is_conversation_member(id));

drop policy if exists "conversations_insert_own" on public.conversations;
create policy "conversations_insert_own"
on public.conversations for insert
to authenticated
with check (created_by = auth.uid());

drop policy if exists "conversation_members_select_members" on public.conversation_members;
create policy "conversation_members_select_members"
on public.conversation_members for select
to authenticated
using (public.is_conversation_member(conversation_id));

drop policy if exists "conversation_members_insert_members" on public.conversation_members;
create policy "conversation_members_insert_members"
on public.conversation_members for insert
to authenticated
with check (
  public.is_conversation_member(conversation_id)
  or exists (
    select 1 from public.conversations c
    where c.id = conversation_id and c.created_by = auth.uid()
  )
);

drop policy if exists "messages_select_members" on public.messages;
create policy "messages_select_members"
on public.messages for select
to authenticated
using (public.is_conversation_member(conversation_id));

drop policy if exists "messages_insert_members_own_sender" on public.messages;
create policy "messages_insert_members_own_sender"
on public.messages for insert
to authenticated
with check (
  sender_id = auth.uid()
  and public.is_conversation_member(conversation_id)
);

-- RPC: create a 1-to-1 conversation and add both users.
create or replace function public.create_direct_conversation(p_other_user uuid)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_conversation uuid;
begin
  if auth.uid() is null then
    raise exception 'Not authenticated';
  end if;

  if p_other_user = auth.uid() then
    raise exception 'Cannot create a conversation with yourself';
  end if;

  select c.id into v_conversation
  from public.conversations c
  where (
    select count(*) from public.conversation_members cm
    where cm.conversation_id = c.id
  ) = 2
  and exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = c.id and cm.user_id = auth.uid()
  )
  and exists (
    select 1 from public.conversation_members cm
    where cm.conversation_id = c.id and cm.user_id = p_other_user
  )
  limit 1;

  if v_conversation is not null then
    return v_conversation;
  end if;

  insert into public.conversations(created_by)
  values (auth.uid())
  returning id into v_conversation;

  insert into public.conversation_members(conversation_id,user_id)
  values (v_conversation,auth.uid()),(v_conversation,p_other_user);

  return v_conversation;
end;
$$;

grant execute on function public.create_direct_conversation(uuid) to authenticated;

-- Exact-email lookup for MVP user discovery.
-- It returns only id + display name, not the email address.
create or replace function public.find_user_by_email(p_email text)
returns table(id uuid, display_name text)
language sql
security definer
stable
set search_path = public
as $$
  select p.id, coalesce(p.display_name, 'VoxChat User')
  from public.profiles p
  join auth.users u on u.id = p.id
  where lower(u.email) = lower(trim(p_email))
    and p.id <> auth.uid()
  limit 1;
$$;

grant execute on function public.find_user_by_email(text) to authenticated;

-- Enable Realtime for messages.
do $$
begin
  alter publication supabase_realtime add table public.messages;
exception
  when duplicate_object then null;
end $$;

alter table public.messages replica identity full;

-- Backfill profiles for users that already existed before the trigger.
insert into public.profiles (id, display_name)
select
  u.id,
  coalesce(u.raw_user_meta_data->>'display_name', split_part(coalesce(u.email,''),'@',1))
from auth.users u
on conflict (id) do nothing;
