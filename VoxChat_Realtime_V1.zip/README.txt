VOXCHAT V1 — REALTIME MESSAGING

1. Open Supabase > SQL Editor.
2. Paste the entire contents of voxchat_realtime_setup.sql.
3. Run it.
4. Replace your current index.html with this index.html.
5. Open the app and create/login to two different VoxChat accounts.
6. From Chats, tap + and enter the other account's email.
7. Send messages. New messages are delivered through Supabase Realtime.

Never put a Supabase secret/service_role key in the frontend.
